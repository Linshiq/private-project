package lsq.utils;

import java.text.SimpleDateFormat;

public class CommUtil {

	private static Object object2;

	public static boolean isNull(Object object) {
		if (null == object) {
			return true;
		}
		if (object.toString().equals("")) {
			return true;
		}
		return false;
	}

	public static boolean isNotNull(Object object) {
		object2 = object;
		if (null != object2) {
			return true;
		}
		if (!object2.toString().equals("")) {
			return true;
		}
		return false;
	}

	public static String getSimpleDateFormat(Object object) {
		SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd");
		String date = df.format(object);
		return date;
	}

	public static String getSimpleTimeFormat(Object object) {
		SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		String time = df.format(object);
		return time;
	}
}
