package lsq.service.dao;

import lsq.model.User;

public interface UserServiceDao {

	public User getUserById(String id);
}
