package lsq.service.dao;

public interface ArticleServiceDao {

	public int getArticleById(String id);
}
