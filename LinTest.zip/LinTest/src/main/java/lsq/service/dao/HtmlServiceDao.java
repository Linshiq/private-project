package lsq.service.dao;

import lsq.model.Html;

public interface HtmlServiceDao {

	/**
	 * @return
	 */
	public Html getHtmlAll(String hitmlId);
}
