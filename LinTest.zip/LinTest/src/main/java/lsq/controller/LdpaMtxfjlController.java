package lsq.controller;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import api.report.ReportUtil;
import error.Error;
import lsq.bean.report.amount.AnnualReport;
import lsq.data.processing.LdpaMtxfjlDataProcess;
import lsq.model.LdpaMtxfjlb;
import lsq.model.LdpaZhhaoye;
import lsq.service.dao.LdpaMtxfjlServiceDao;
import lsq.service.dao.LdpaZhhaoyeServiceDao;
import lsq.utils.CommUtil;

@Controller
@RequestMapping("/")
public class LdpaMtxfjlController {

	private static final Logger logger = Logger.getLogger(LdpaMtxfjlController.class);
	
	private static LdpaMtxfjlServiceDao ldpaMtxfjlService;

	public LdpaMtxfjlServiceDao getLdpaMtxfjlService() {
		return ldpaMtxfjlService;
	}

	@Autowired
	public void setLdpaMtxfjlService(LdpaMtxfjlServiceDao ldpaMtxfjlService) {
		logger.debug("LdpaMtxfjlController.setLdpaMtxfjlService start");
		
		LdpaMtxfjlController.ldpaMtxfjlService = ldpaMtxfjlService;
		LdpaMtxfjlDataProcess ldpaMtxfjlDataProcess = new LdpaMtxfjlDataProcess();
		ldpaMtxfjlDataProcess.setLdpaMtxfjlService(ldpaMtxfjlService);
		
		logger.debug("LdpaMtxfjlController.setLdpaMtxfjlService end");
	}
	
	@RequestMapping(value = "/table/dd", method = RequestMethod.GET)
	public String getWho(Model model, @RequestParam("oneday") String oneday) {// 根据判断进行重定向
		logger.debug("LdpaMtxfjlController.getWho start");
		System.out.println(oneday);
		model.addAttribute("oneday", oneday);
		if (oneday.length() == 10){
			
			logger.debug("LdpaMtxfjlController.getWho end");
			return "redirect:/table/daybaobiao";
		}
		else{
			logger.debug("LdpaMtxfjlController.getWho end");
			return "redirect:/table/yearbaobiao";
		}
	}

	// @RequestMapping("/table/yue")
	// public String getYueReport(Model model) {
	//
	// LdpaZhhaoyeController l = new LdpaZhhaoyeController();
	// return l.getYueReport(model);
	// }
	//获取年度消费比重报表
	@RequestMapping(value ="/table/bizhong", method = RequestMethod.GET)
	public String getAnnualConsumptionReport(Model model) {
		logger.debug("LdpaMtxfjlController.getAnnualConsumptionReport start");
		
		logger.debug("LdpaMtxfjlController.getAnnualConsumptionReport end");
		return "/WEB-INF/jsp/report/annualConsumptionReport";
	}
	
	@RequestMapping("/table/yearbaobiao")
	public String getAnnualReport(Model model) {

		Map<String, List<AnnualReport>> allMonthList = LdpaMtxfjlDataProcess.getSpendingEveryDay();

		StringBuffer allInfo = new StringBuffer();// 组装所有月份
		allInfo.append("series: ["); // 组装报表数据

		Iterator<String> keys = allMonthList.keySet().iterator();
		while (keys.hasNext()) {
			String key = (String) keys.next();
			for (int i = 1; i <= 12; i++) {
				if (i < 10) {
					String exitKey = "0" + i;
					if (exitKey.equals(key)) {// 寻找记录中存在的月份
						System.out.println("这里面有" + exitKey);

						List<AnnualReport> a = allMonthList.get(exitKey);
						if (a.size() > 0) {
							StringBuffer monthSB = new StringBuffer();// 拼接月份数据
							monthSB.append("{");
							monthSB.append("name: '" + exitKey + "月份'").append(",");
							monthSB.append("data:[");
							for (AnnualReport a1 : a) {
								System.out.println(a1.getDate() + ":" + a1.getAmout());
								monthSB.append(a1.getAmout()).append(",");
							}
							monthSB.append("]},");
							allInfo.append(monthSB);
						} else
							continue;
					}

				} else {
					String exitKey = i + "";
					if (exitKey.equals(key)) {// 寻找记录中存在的月份
						System.out.println("这里面有" + exitKey);

						List<AnnualReport> a = allMonthList.get(exitKey);
						if (a.size() > 0) {
							StringBuffer monthSB = new StringBuffer();// 拼接月份数据
							monthSB.append("{");
							monthSB.append("name: '" + exitKey + "月份'").append(",");
							monthSB.append("data:[");
							for (AnnualReport a1 : a) {
								System.out.println(a1.getDate() + ":" + a1.getAmout());
								monthSB.append(a1.getAmout()).append(",");
							}
							monthSB.append("]},");
							allInfo.append(monthSB);
						} else
							continue;
					}

				}
			}
		}
		allInfo.append("]");

		StringBuffer xSb = new StringBuffer(); // 建立X轴
		xSb.append(ReportUtil.getX("日期")).append("[");
		for (int i = 1; i <= 31; i++) // 天数
			xSb.append("'" + i + "'").append(",");
		xSb.append("]");
		StringBuffer ySb = new StringBuffer();
		ySb.append(ReportUtil.getYHead("金额")).append("["); // 建立Y轴
		for (int i = 0; i <= 2000; i = i + 100) // 金额
			ySb.append("'" + i + "'").append(",");
		ySb.append("]");

		model.addAttribute("data2", allInfo.toString());
		model.addAttribute("x", xSb.toString());
		model.addAttribute("y", ySb.toString());
		model.addAttribute("title", ReportUtil.getTitle("2016报表"));// 设置报表标题

		return "/WEB-INF/jsp/report/annual_report";
	}

	// 返回一天的消费报表
	@RequestMapping("/table/daybaobiao")
	public String getDayReport(Model model, @RequestParam("oneday") String oneday) {

		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		Date date = null;
		String oneDayStr = oneday;
		try {
			date = sdf.parse(oneDayStr);
			List<LdpaMtxfjlb> ldpaMtxfjlbList = LdpaMtxfjlDataProcess.getOneDateData(date);

			StringBuffer allInfo = new StringBuffer();// 组装当天所有数据
			allInfo.append("series: ["); // 组装报表数据
			allInfo.append("{");
			allInfo.append("name: '" + oneDayStr + "'").append(",");
			allInfo.append("data:[");
			if (ldpaMtxfjlbList.size() > 0) {
				for (LdpaMtxfjlb l : ldpaMtxfjlbList) {

					System.out.println("ID:" + l.getId() + " 时间:" + l.getTime() + " 类型:" + l.getConsumptionType()
							+ " 消费:" + l.getExpenditure() + " 收入:" + l.getIncome());
					allInfo.append(l.getExpenditure() - l.getIncome()).append(",");
				}
			}
			allInfo.append("]},");
			allInfo.append("]");
			StringBuffer xSb = new StringBuffer(); // 建立X轴
			xSb.append(ReportUtil.getX("时间")).append("[");
			if (ldpaMtxfjlbList.size() > 0) {
				for (LdpaMtxfjlb l : ldpaMtxfjlbList) {
					xSb.append("'" + l.getTime().substring(1) + "'").append(",");
				}
			}
			// for (int i = 0; i < 24; i++) // 小时
			// xSb.append("'" + i + "'").append(",");
			xSb.append("]");
			StringBuffer ySb = new StringBuffer();
			ySb.append(ReportUtil.getYHead("金额")).append("["); // 建立Y轴
			for (int i = 0; i <= 10; i = i + 1) // 金额
				ySb.append("'" + i + "'").append(",");
			ySb.append("]");

			model.addAttribute("data2", allInfo.toString());
			model.addAttribute("x", xSb.toString());
			model.addAttribute("y", ySb.toString());
			model.addAttribute("title", ReportUtil.getTitle(oneday + "消费报表"));// 设置报表标题

			model.addAttribute("leftTitle", oneday);
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return "/WEB-INF/jsp/report/every_day_report";
	}

	// 获取指定月份消费折线图
	@RequestMapping("/table/monthbaobiao")
	public String getMonthReport(Model model, @RequestParam("oneMonth") String oneMonth) {

		List<LdpaZhhaoye> ldpaZhhaoyeList = LdpaMtxfjlDataProcess.getOneMonthData(oneMonth);

		StringBuffer allInfo = new StringBuffer();// 组装当月所有数据
		allInfo.append("series: ["); // 组装报表数据
		allInfo.append("{");
		allInfo.append("name: '" + oneMonth + "月消费'").append(",");
		allInfo.append("data:[");
		if (ldpaZhhaoyeList.size() > 0) {
			for (LdpaZhhaoye l : ldpaZhhaoyeList) {

				allInfo.append(l.getTotalConsumption()).append(",");
			}
		}
		allInfo.append("]},");
		allInfo.append("{");
		allInfo.append("name: '" + oneMonth + "月收入" + "'").append(",");
		allInfo.append("data:[");
		if (ldpaZhhaoyeList.size() > 0) {
			for (LdpaZhhaoye l : ldpaZhhaoyeList) {

				allInfo.append(l.getTotalIncome()).append(",");
			}
		}
		allInfo.append("]},");
		allInfo.append("{");
		allInfo.append("name: '" + oneMonth + "月余额" + "'").append(",");
		allInfo.append("data:[");
		if (ldpaZhhaoyeList.size() > 0) {
			for (LdpaZhhaoye l : ldpaZhhaoyeList) {

				allInfo.append(l.getBalance()).append(",");
			}
		}
		allInfo.append("]},");
		allInfo.append("]");
		StringBuffer xSb = new StringBuffer(); // 建立X轴
		xSb.append(ReportUtil.getX("日期(天)")).append("[");
		for (int i = 1; i <= 31; i++) // 天数
			xSb.append("'" + i + "'").append(",");
		xSb.append("]");
		StringBuffer ySb = new StringBuffer();
		ySb.append(ReportUtil.getYHead("金额")).append("["); // 建立Y轴
		for (int i = 0; i <= 10; i = i + 1) // 金额
			ySb.append("'" + i + "'").append(",");
		ySb.append("]");

		model.addAttribute("data2", allInfo.toString());
		model.addAttribute("x", xSb.toString());
		model.addAttribute("y", ySb.toString());
		model.addAttribute("title", ReportUtil.getTitle(oneMonth + "月消费报表"));// 设置报表标题

		// model.addAttribute("leftTitle", oneMonth);
		return "/WEB-INF/jsp/report/month_report";
	}

}
