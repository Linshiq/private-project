package lsq.test;

import org.apache.log4j.Logger;

import lsq.controller.AllController;

public class test {

	public static Logger logger = Logger.getLogger(AllController.class);
	
	public static void main(String[] args) {
		
		logger.info("this is log4j");
	}
}
