package lsq.test;

import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import lsq.model.LdpaZhhaoye;
import lsq.service.dao.ArticleServiceDao;
import lsq.service.dao.LdpaMtxfjlServiceDao;
import lsq.service.dao.LdpaZhhaoyeServiceDao;
import lsq.service.dao.UserServiceDao;
import lsq.utils.CommUtil;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "classpath:spring.xml", "classpath*:spring-mybatis.xml" })
public class TestMybatis {
	UserServiceDao usd;
	ArticleServiceDao ar;
	LdpaMtxfjlServiceDao ldpaMtxfjlService;
	LdpaZhhaoyeServiceDao ldpaZhhaoyeService;

	public  LdpaZhhaoyeServiceDao getLdpaZhhaoyeService() {
		return ldpaZhhaoyeService;
	}
	@Autowired
	public  void setLdpaZhhaoyeService(LdpaZhhaoyeServiceDao ldpaZhhaoyeService) {
		this.ldpaZhhaoyeService = ldpaZhhaoyeService;
	}
	public LdpaMtxfjlServiceDao getLdpaMtxfjlService() {
		return ldpaMtxfjlService;
	}

	@Autowired
	public void setLdpaMtxfjlService(LdpaMtxfjlServiceDao ldpaMtxfjlService) {
		this.ldpaMtxfjlService = ldpaMtxfjlService;
	}

	@Test
	public void test() {
		
		List<LdpaZhhaoye> l = ldpaZhhaoyeService.selectByMonth("08");
		
		for(LdpaZhhaoye s:l){
			
			System.out.println(" DATE:"+CommUtil.getSimpleDateFormat(s.getDate()));
		}
	}
}
