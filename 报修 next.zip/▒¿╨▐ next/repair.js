    /* 如果其中有一个函数出错了，这个JS文件就不能被引用了。*/
    
    //当前时间 
    function today(){
        var mydate = new Date();
        var weekday=["星期日","星期一","星期二","星期三","星期四","星期五","星期六"];
        var now="现在是："+mydate.getFullYear()+"年"+(mydate.getMonth()+1)+"月"+mydate.getDate()+"日  "+mydate.getHours()+":"+mydate.getMinutes()+" "+weekday[mydate.getDay()];
        document.getElementById("nowDiv").innerHTML = now;
    }
    //清空文本域的默认提示
    function clearText(field){
        if (field.defaultValue == field.value) field.value = '';
        else if (field.value =='') field.value = field.defaultValue;
    }
    //按钮数值变化以及按钮不可用
    function changeBtn(){
         var c=document.getElementById("btn_finish").value;
         c="已完成";
         document.getElementById("btn_finish").value=c;
         document.getElementById("btn_finish").disabled=true;
    }
    //考虑浏览器兼容的提示关闭本页面
    function wClose(){
        if (confirm("您确定要关闭本页吗？")){
            if (navigator.userAgent.indexOf("MSIE") > 0) {
                if (navigator.userAgent.indexOf("MSIE 6.0") > 0) {
                    window.opener = null;
                    window.close();
                } else {
                    window.open('', '_top');
                    window.top.close();
                    }
                }
                else if (navigator.userAgent.indexOf("Firefox") > 0) {
            window.location.href = 'about:blank ';
            } else {
            window.opener = null;
            window.open('', '_self', '');
            window.close();
            }
        }
        else{}
    }
    //考虑浏览器兼容的不提示关闭本页面
    function CloseWebPage(){
        if (navigator.userAgent.indexOf("MSIE") > 0) {
        if (navigator.userAgent.indexOf("MSIE 6.0") > 0) {
            window.opener = null;
            window.close();
        } else {
            window.open('', '_top');
            window.top.close();
        }
        }
        else if (navigator.userAgent.indexOf("Firefox") > 0) {
            window.location.href = 'about:blank ';
        } else {
            window.opener = null;
            window.open('', '_self', '');
            window.close();
        }
    }
    //提交成功
    function success(){
        var y=alert("提交成功!");
        if(y=="确定"){
            window.location.href= ctx + "/repairEntre";
        }
    }
    
//输入框获得焦点时，显示提示内容
function showDesc(obj)
{  
   var id= obj.name;
   document.getElementById(id).style.display="inline";
}
//输入框失去焦点时检验输入内容是否有效
function checkText(obj)
{
   //获取输入框的id值
   var id= obj.name;
   var text=document.getElementById(id.toString().toUpperCase()).value;

   //判断是否为空
   if(text.replace(/\s/g, "")=="")
   {
      document.getElementById(id).innerHTML="输入不能为空";
   }
   else
   {
     //组装方法
     //取首字母转换为大写,其余不变
     var firstChar=id.charAt(0).toString().toUpperCase();
     //
     var strsub=id.substring(1,id.length);
     var strMethod="check"+firstChar+strsub+"()";
     var isTrue = eval(strMethod);
     if(isTrue)
     {
         document.getElementById(id).innerHTML="输入有效";
     }
   }

   
}
function checkUsername()
{
    //只简单的判断用户名的长度
    var id = document.getElementById("USERNAME");
    var username=id.value;    
    if(username.length > 10)
    {
      document.getElementById(id.name).innerHTML = "输入的用户名过长";
      return false;
    } 
    else
    return true;
}
function checkPassword()
{
    var password = document.getElementById("PASSWORD").value;    
    return true;
}
function checkPassword2()
{
     var id=document.getElementById("PASSWORD");
     var id2=document.getElementById("PASSWORD2");
     var password = id.value;    
     var password2 = id2.value;
     if(password!=password2)
     {
        document.getElementById(id.name).innerHTML="密码不一致";
        return false;
     }
     return true;    
}
function checkIDNumber()
{
  var id=document.getElementById("IDNUMBER"); 
  var IDNumber =id.value;
  if(IDNumber.length<18||IDNumber.length>19)
  {
    document.getElementById(id.name).innerHTML="身份证号长度有误";
    return false;
  }
  var expr=/([0]{18}[x|y]?)|([1]{18}[x|y]?)/i;
  if(expr.test(IDNumber))
  {
     document.getElementById(id.name).innerHTML="身份证号不可以全'0'或全'1'";
     return false;
  }
  return true;
}
function checkPhoneNumber()
{
// 利用正则表达式对输入数据匹配
   var id=document.getElementById("PHONENUMBER");
   var phone = id.value;     
//匹配到一个非数字字符，则返回false 
   var expr =  /\D/i;
   if(expr.test(phone))
   {
      document.getElementById(id.name).innerHTML="不能输入非数字字符";
      return false;
   }
   return true;

}