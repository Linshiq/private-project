package login.base;
/** 
* @author  LinShiqin: 
* @date 创建时间：2016年4月20日 下午2:25:46 
* @return  
*/
public class User {

	private String id;
	private String userName;
	private String userPsd ;
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getUserPsd() {
		return userPsd;
	}
	public void setUserPsd(String userPsd) {
		this.userPsd = userPsd;
	}
	
	
	
}
