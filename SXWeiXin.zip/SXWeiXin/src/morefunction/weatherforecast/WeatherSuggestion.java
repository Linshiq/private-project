package morefunction.weatherforecast;



public class WeatherSuggestion {

	private String brf; //简介
	private String txt; //详细描叙
	public String getBrf() {
		return brf;
	}
	public void setBrf(String brf) {
		this.brf = brf;
	}
	public String getTxt() {
		return txt;
	}
	public void setTxt(String txt) {
		this.txt = txt;
	}
}
