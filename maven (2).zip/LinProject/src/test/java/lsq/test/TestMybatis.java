package lsq.test;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import lsq.model.User;
import lsq.service.dao.UserServiceDao;

//@RunWith(SpringJUnit4ClassRunner.class)
//@ContextConfiguration(locations = { "classpath:spring.xml", "classpath:spring-mybatis.xml" })
public class TestMybatis {
	UserServiceDao usd;

	public UserServiceDao getUsd() {
		return usd;
	}

	@Autowired
	public void setUsd(UserServiceDao usd) {
		this.usd = usd;
	}

	@Test
	public void test() {

//		User u = usd.getUserById("1");
//		System.out.println(u.getName());
	}
}

// ��spring-testʱ����ôд
// public class TestMybatis {
// ApplicationContext ac;
//
// @Before
// public void before(){
// ac = new ClassPathXmlApplicationContext(new String[]
// {"spring.xml","spring-mybatis.xml"});
// }
//
// @Test
// public void test(){
// UserServiceDao usd =(UserServiceDao) ac.getBean("service");
// User u = usd.getUserById("1");
// System.out.println(u.getName());
// }
// }
